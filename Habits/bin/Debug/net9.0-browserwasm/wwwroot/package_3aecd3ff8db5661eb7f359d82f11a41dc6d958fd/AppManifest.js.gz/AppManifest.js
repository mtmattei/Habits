var UnoAppManifest = {
    displayName: "Habits",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}